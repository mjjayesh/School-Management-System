<?php
include_once('main.php');
include_once('../../service/mysqlcon.php');
include_once('index.php');
?>
<html>
<body>



<div class ="header">
<?php
$sql = "SELECT * FROM teachers WHERE id='$check';";
$res = mysqli_query($link, $sql);
while($row = mysqli_fetch_array($res)){
   echo "<center>";
   echo "ID: ".$row['id']."<br />";
   echo "Name: ".$row['name']."<br />";
   echo "Password: ".$row['password']."<br />";
   echo "Phone: ".$row['phone']."<br />";
   
   echo "Email Address: ".$row['email']."<br />";
   
   echo "Salary: ".$row['salary']."<br />";
   echo "</center>";
   
}
?>
</div>
</body>
</html>