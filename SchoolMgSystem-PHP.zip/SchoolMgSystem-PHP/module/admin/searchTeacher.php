<?php
include_once('main.php');
include_once('../../service/mysqlcon.php');
$searchKey = $_GET['key'];

$string = "<tr>
    <th>ID</th>
    <th>Name</th>
    <th>Password</th>
    <th>Phone</th>
    <th>Email</th>
    <th>Salary</th>
    
</tr>";
$sql = "SELECT * FROM teachers WHERE id like '$searchKey%' OR name like '$searchKey%';";
$res = mysqli_query($link, $sql);
while($row = mysqli_fetch_array($res)){
    $string .= '<tr><td>'.$row['id'].'</td><td>'.$row['name'].
    '</td><td>'.$row['password'].'</td><td>'.$row['phone'].'</td><td>'.$row['email'].
    '</td><td>'.$row['salary'].'</td></tr>';
}
echo $string;
?>
