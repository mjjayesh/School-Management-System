-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 25, 2023 at 04:49 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `schoolmsdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `phone` varchar(13) NOT NULL,
  `email` varchar(20) NOT NULL,
  `dob` date NOT NULL,
  `hiredate` date NOT NULL,
  `address` varchar(30) NOT NULL,
  `sex` varchar(7) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `password`, `phone`, `email`, `dob`, `hiredate`, `address`, `sex`) VALUES
(1, 'Admin1', 'Admin1', '1254758456', 'admin1@gmail.com', '0000-00-00', '0000-00-00', 'Pune', 'Male');

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `id` int(11) NOT NULL,
  `date` date NOT NULL,
  `attendedid` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`id`, `date`, `attendedid`) VALUES
(18, '2016-05-04', 'te-123-1'),
(20, '2016-05-01', 'te-123-1'),
(21, '2016-04-12', 'te-123-1'),
(22, '2016-05-04', 'te-124-1'),
(23, '2016-04-19', 'te-124-1'),
(24, '2016-05-02', 'te-124-1'),
(25, '2016-05-04', 'sta-123-1'),
(26, '2016-05-05', 'sta-123-1'),
(27, '2016-04-04', 'sta-123-1'),
(28, '2016-04-05', 'sta-123-1'),
(29, '2021-04-06', 'te-123-1'),
(30, '2021-04-06', 'sta-123-1'),
(31, '2021-04-06', 'st-123-1'),
(32, '2021-04-06', 'st-124-1');

-- --------------------------------------------------------

--
-- Table structure for table `availablecourse`
--

CREATE TABLE `availablecourse` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `classid` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `availablecourse`
--

INSERT INTO `availablecourse` (`id`, `name`, `classid`) VALUES
(1, 'Bangla 1st', '1'),
(2, 'Bangla 1st', '2'),
(3, 'Bangla 1st', '3'),
(4, 'Bangla 1st', '4'),
(5, 'Bangla 1st', '5'),
(6, 'Bangla 1st', '6'),
(7, 'Bangla 1st', '7'),
(8, 'Bangla 1st', '8'),
(9, 'Bangla 1st', '9'),
(10, 'Bangla 1st', '10'),
(11, 'Bangla 2nd', '1'),
(12, 'Bangla 2nd', '2'),
(13, 'Bangla 2nd', '3'),
(14, 'Bangla 2nd', '4'),
(15, 'Bangla 2nd', '5'),
(16, 'Bangla 2nd', '6'),
(17, 'Bangla 2nd', '7'),
(18, 'Bangla 2nd', '8'),
(19, 'Bangla 2nd', '9'),
(20, 'Bangla 2nd', '10'),
(21, 'English 1st', '1'),
(22, 'English 1st', '2'),
(23, 'English 1st', '3'),
(24, 'English 1st', '4'),
(25, 'English 1st', '5'),
(26, 'English 1st', '6'),
(27, 'English 1st', '7'),
(28, 'English 1st', '8'),
(29, 'English 1st', '9'),
(30, 'English 1st', '10'),
(31, 'English 2nd', '1'),
(32, 'English 2nd', '2'),
(33, 'English 2nd', '3'),
(34, 'English 2nd', '4'),
(35, 'English 2nd', '5'),
(36, 'English 2nd', '6'),
(37, 'English 2nd', '7'),
(38, 'English 2nd', '8'),
(39, 'English 2nd', '9'),
(40, 'English 2nd', '10');

-- --------------------------------------------------------

--
-- Table structure for table `class`
--

CREATE TABLE `class` (
  `id` varchar(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `room` varchar(20) NOT NULL,
  `section` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `class`
--

INSERT INTO `class` (`id`, `name`, `room`, `section`) VALUES
('1A', 'One', '101', 'A'),
('1B', 'One', '101', 'B'),
('2A', 'Two', '201', 'A'),
('2B', 'Two', '202', 'B'),
('3A', 'Three', '301', 'A'),
('3B', 'Three', '302', 'B'),
('4A', 'Four', '401', 'A'),
('4B', 'Four', '402', 'B'),
('5A', 'Five', '501', 'A'),
('5B', 'Five', '502', 'B'),
('6A', 'Six', '601', 'A'),
('6B', 'Six', '602', 'B'),
('7A', 'Seven', '701', 'A'),
('7B', 'Seven', '702', 'B'),
('8A', 'Eight', '801', 'A'),
('8B', 'Eight', '802', 'B'),
('9A', 'Nine', '901', 'A'),
('9B', 'Nine', '902', 'B'),
('10S', 'Ten', '1001', 'Science'),
('10A', 'Ten', '1002', 'Arts'),
('10C', 'Ten', '1002', 'Commerce');

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `id` varchar(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `teacherid` varchar(20) NOT NULL,
  `studentid` varchar(20) NOT NULL,
  `classid` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`id`, `name`, `teacherid`, `studentid`, `classid`) VALUES
('1', 'Bangla 1st', 'te-124-1', 'st-123-1', '1A'),
('1', 'Bangla 1st', 'te-124-1', 'st-124-1', '1A');

-- --------------------------------------------------------

--
-- Table structure for table `examschedule`
--

CREATE TABLE `examschedule` (
  `id` varchar(20) NOT NULL,
  `examdate` date NOT NULL,
  `time` varchar(20) NOT NULL,
  `courseid` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `examschedule`
--

INSERT INTO `examschedule` (`id`, `examdate`, `time`, `courseid`) VALUES
('145', '2016-05-06', '2:00-4:00', '1'),
('sh-10', '2021-04-06', '10:00 - 12:30', '4'),
('sh-20', '2021-04-06', '01:00 - 03:00', '2');

-- --------------------------------------------------------

--
-- Table structure for table `grade`
--

CREATE TABLE `grade` (
  `id` int(11) NOT NULL,
  `studentid` varchar(20) NOT NULL,
  `grade` varchar(5) NOT NULL,
  `courseid` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `grade`
--

INSERT INTO `grade` (`id`, `studentid`, `grade`, `courseid`) VALUES
(1, 'st-123-1', 'C', '8'),
(2, 'st-123-1', 'F', '4'),
(3, 'st-125-1', 'D+', '1'),
(4, 'st-123-1', 'D+', '1'),
(5, 'st-124-1', 'C+', '1'),
(6, 'st-124-1', 'A+', '1');

-- --------------------------------------------------------

--
-- Table structure for table `parents`
--

CREATE TABLE `parents` (
  `id` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `fathername` varchar(20) NOT NULL,
  `mothername` varchar(20) NOT NULL,
  `fatherphone` varchar(13) NOT NULL,
  `motherphone` varchar(13) NOT NULL,
  `address` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `parents`
--

INSERT INTO `parents` (`id`, `password`, `fathername`, `mothername`, `fatherphone`, `motherphone`, `address`) VALUES
('pa-123-1', '123', 'Eric', 'Sophie', '01711000000', '01711000000', '4286  Raoul Wallenberg Place'),
('pa-124-1', '123', 'John', 'Riley', '01724242424', '01924242314', '2549  Simpson Avenue');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `id` int(11) NOT NULL,
  `studentid` varchar(20) NOT NULL,
  `amount` double NOT NULL,
  `month` varchar(10) NOT NULL,
  `year` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`id`, `studentid`, `amount`, `month`, `year`) VALUES
(1, 'st-123-1', 500, '5', '2016'),
(2, 'st-123-1', 500, '4', '2016'),
(3, 'st-124-1', 500, '5', '2016'),
(4, 'st-123-1', 4500, 'March 10', '2021'),
(5, 'st-123-1', 4000, 'April 6', '2021');

-- --------------------------------------------------------

--
-- Table structure for table `report`
--

CREATE TABLE `report` (
  `reportid` int(11) NOT NULL,
  `studentid` varchar(20) NOT NULL,
  `teacherid` varchar(20) NOT NULL,
  `message` varchar(500) NOT NULL,
  `courseid` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `report`
--

INSERT INTO `report` (`reportid`, `studentid`, `teacherid`, `message`, `courseid`) VALUES
(1, 'st-123-1', 'te-123-1', 'Good Boy', '790'),
(2, 'st-124-1', 'te-123-1', 'Good boy But not honest.', '790'),
(3, 'st-123-1', 'te-124-1', ' good', '1'),
(4, 'st-124-1', 'te-124-1', ' Good one, keep it up!', '1');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `id` varchar(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `sex` varchar(7) NOT NULL,
  `dob` date NOT NULL,
  `hiredate` date NOT NULL,
  `address` varchar(30) NOT NULL,
  `salary` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`id`, `name`, `password`, `phone`, `email`, `sex`, `dob`, `hiredate`, `address`, `salary`) VALUES
('sta-123-1', 'Scott', '123', '1597534568', 'scootpel@gmail.com', 'Male', '1980-11-08', '2015-10-15', '2333  Cody Ridge Road', 25000),
('sta-124-1', 'Patrick', '123', '7412531325', 'pforpat@school.com', 'Male', '1990-03-26', '2017-05-12', '321  McDonald Avenue', 19500),
('sta-125-1', 'Aaron', '123', '2587532224', 'aarontay@gmail.com', 'Male', '1992-08-19', '2010-05-29', '4927  Water Street', 31000),
('sta-126-1', 'Peterson', '123', '2574545888', 'peteson@gmail.com', 'Male', '2021-04-01', '2012-05-05', '2950  Parrill Court', 27000);

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `phone` varchar(13) NOT NULL,
  `email` varchar(20) NOT NULL,
  `sex` varchar(7) NOT NULL,
  `dob` date NOT NULL,
  `addmissiondate` date NOT NULL,
  `address` varchar(50) NOT NULL,
  `parentid` varchar(20) NOT NULL,
  `classid` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `name`, `password`, `phone`, `email`, `sex`, `dob`, `addmissiondate`, `address`, `parentid`, `classid`) VALUES
(100, 'Jayesh', 'jayesh1', '752015258', 'jay@gmail.com', '', '0000-00-00', '0000-00-00', '', '', '4th'),
(101, 'Piyush', 'Piyush1', '752154258', 'Piyush@gmail.com', '', '0000-00-00', '0000-00-00', '', '', '5th'),
(102, 'Ramesh', 'Ramesh1', '565856985', 'Ramesh@gmail.com', '', '0000-00-00', '0000-00-00', '', '', '3rd'),
(103, 'Pramod', 'Pramod1', '785452152', 'Pramod@gmail.com', '', '0000-00-00', '0000-00-00', '', '', '1st'),
(104, 'Kiran', 'Kiran1', '9585658456', 'Kiran@gmail.com', '', '0000-00-00', '0000-00-00', '', '', '5th'),
(105, 'Ravi', 'Ravi1', '6589658964', 'Ravi@gmail.com', '', '0000-00-00', '0000-00-00', '', '', '1st'),
(106, 'Ram', 'Ram1', '256985654', 'Ram@gmail.com', '', '0000-00-00', '0000-00-00', '', '', '1st'),
(107, 'Mangesh', 'Mangesh1', '8565412545', 'Mangesh@gmail.com', '', '0000-00-00', '0000-00-00', '', '', '1st'),
(108, 'Shital', 'Shital1', '1254758456', 'Shital@gmail.com', '', '0000-00-00', '0000-00-00', '', '', '7th'),
(109, 'Pooja', 'Pooja1', '7896541236', 'Pooja@gmail.com', '', '0000-00-00', '0000-00-00', '', '', '3rd'),
(110, 'Hetal', 'Hetal1', '78452152365', 'Hetal@gmail.com', '', '0000-00-00', '0000-00-00', '', '', '1st'),
(111, 'Raj', 'Raj1', '9845632152', 'Raj@gmail.com', '', '0000-00-00', '0000-00-00', '', '', '3rd'),
(112, 'Suresh', 'Suresh1', '25469858745', 'Suresh@gmail.com', '', '0000-00-00', '0000-00-00', '', '', '3rd'),
(113, 'Mahesh', 'Mahesh1', '1254658965', 'Mahesh@gmail.com', '', '0000-00-00', '0000-00-00', '', '', '1st'),
(114, 'Dinesh', 'Dinesh1', '7546521526', 'Dinesh@gmail.com', '', '0000-00-00', '0000-00-00', '', '', '6th'),
(115, 'Savita', 'Savita1', '8659856458', 'Savita@gmail.com', '', '0000-00-00', '0000-00-00', '', '', '1st'),
(116, 'Rani', 'Rani1', '1254758456', 'Rani@gmail.com', '', '0000-00-00', '0000-00-00', '', '', '1st'),
(117, 'Yash', 'Yash1', '3256589654', 'Yash@gmail.com', '', '0000-00-00', '0000-00-00', '', '', '3rd'),
(118, 'Samadhan', 'Samadhan1', '7896541256', 'Samadhan@gmail.com', '', '0000-00-00', '0000-00-00', '', '', '1st'),
(119, 'Lalita', 'Lalita1', '754856256', 'Lalita@gmail.com', '', '0000-00-00', '0000-00-00', '', '', '1st'),
(120, 'Snehal', 'Snehal1', '8547856589', 'Snehal@gmail.com', '', '0000-00-00', '0000-00-00', '', '', '2nd'),
(121, 'Pramod', 'Pramod1', '785452152', 'Pramod@gmail.com', '', '0000-00-00', '0000-00-00', '', '', '3rd'),
(122, 'Snehal', 'Snehal1', '8547856589', 'Snehal@gmail.com', '', '0000-00-00', '0000-00-00', '', '', '7th'),
(123, 'Hetal', 'Hetal1', '78452152365', 'Hetal@gmail.com', '', '0000-00-00', '0000-00-00', '', '', '8th'),
(124, 'Piyush', 'Piyush1', '752154258', 'Piyush@gmail.com', '', '0000-00-00', '0000-00-00', '', '', '56h'),
(125, 'Ramesh', 'Ramesh1', '565856985', 'Ramesh@gmail.com', '', '0000-00-00', '0000-00-00', '', '', '1st'),
(126, 'Pooja', 'Pooja1', '7896541236', 'Pooja@gmail.com', '', '0000-00-00', '0000-00-00', '', '', '9th'),
(127, 'Suresh', 'Suresh1', '25469858745', 'Suresh@gmail.com', '', '0000-00-00', '0000-00-00', '', '', '5th'),
(128, 'Kiran', 'Kiran1', '9585658456', 'Kiran@gmail.com', '', '0000-00-00', '0000-00-00', '', '', '7th'),
(129, 'Ravi', 'Ravi1', '6589658964', 'Ravi@gmail.com', '', '0000-00-00', '0000-00-00', '', '', '2nd'),
(130, 'Ram', 'Ram1', '256985654', 'Ram@gmail.com', '', '0000-00-00', '0000-00-00', '', '', '6th'),
(131, 'Shital', 'Shital1', '1254758456', 'Shital@gmail.com', '', '0000-00-00', '0000-00-00', '', '', '5th'),
(132, 'Mangesh', 'Mangesh1', '8565412545', 'Mangesh@gmail.com', '', '0000-00-00', '0000-00-00', '', '', '2nd'),
(133, 'Raj', 'Raj1', '9845632152', 'Raj@gmail.com', '', '0000-00-00', '0000-00-00', '', '', '5th'),
(134, 'Yash', 'Yash1', '3256589654', 'Yash@gmail.com', '', '0000-00-00', '0000-00-00', '', '', '3rd'),
(135, 'Dinesh', 'Dinesh1', '7546521526', 'Dinesh@gmail.com', '', '0000-00-00', '0000-00-00', '', '', '4th'),
(136, 'Rani', 'Rani1', '1254758456', 'Rani@gmail.com', '', '0000-00-00', '0000-00-00', '', '', '5th'),
(137, 'Samadhan', 'Samadhan1', '7896541256', 'Samadhan@gmail.com', '', '0000-00-00', '0000-00-00', '', '', '7th'),
(138, 'Lalita', 'Lalita1', '754856256', 'Lalita@gmail.com', '', '0000-00-00', '0000-00-00', '', '', '8th'),
(139, 'Mahesh', 'Mahesh1', '1254658965', 'Mahesh@gmail.com', '', '0000-00-00', '0000-00-00', '', '', '9th'),
(140, 'Savita', 'Savita1', '8659856458', 'Savita@gmail.com', '', '0000-00-00', '0000-00-00', '', '', '2nd');

-- --------------------------------------------------------

--
-- Table structure for table `takencoursebyteacher`
--

CREATE TABLE `takencoursebyteacher` (
  `id` int(11) NOT NULL,
  `courseid` varchar(20) NOT NULL,
  `teacherid` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `takencoursebyteacher`
--

INSERT INTO `takencoursebyteacher` (`id`, `courseid`, `teacherid`) VALUES
(1, '4', 'te-123-1'),
(2, '8', 'te-123-1'),
(3, '1', 'te-124-1'),
(4, '2', 'te-124-1'),
(5, '18', 'te-125-1'),
(6, '19', 'te-125-1'),
(7, '11', 'te-125-1'),
(8, '24', 'te-126-1'),
(9, '23', 'te-126-1'),
(10, '22', 'te-126-1'),
(11, '4', 'te-124-1'),
(12, '5', 'te-123-1'),
(13, '6', 'te-125-1'),
(14, '7', 'te-127-1'),
(15, '9', 'te-127-1'),
(16, '10', 'te-127-1'),
(17, '17', 'te-125-1'),
(18, '16', 'te-125-1'),
(19, '15', 'te-125-1'),
(20, '14', 'te-126-1'),
(21, '13', 'te-126-1'),
(22, '12', 'te-126-1');

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE `teachers` (
  `id` int(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `phone` varchar(13) NOT NULL,
  `email` varchar(20) NOT NULL,
  `address` varchar(30) NOT NULL,
  `sex` varchar(7) NOT NULL,
  `dob` date NOT NULL,
  `hiredate` date NOT NULL,
  `salary` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`id`, `name`, `password`, `phone`, `email`, `address`, `sex`, `dob`, `hiredate`, `salary`) VALUES
(500, 'Neha', 'neha1', '254854587', 'n@gmail.com', '', '', '0000-00-00', '0000-00-00', 50000);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userid` int(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `usertype` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userid`, `password`, `usertype`) VALUES
(1, 'Admin1', 'admin'),
(100, 'jayesh1', 'student'),
(101, 'Piyush1', 'student'),
(102, 'Ramesh1', 'student'),
(103, 'Pramod1', 'student'),
(104, 'Kiran1', 'student'),
(105, 'Ravi1', 'student'),
(106, 'Ram1', 'student'),
(107, 'Mangesh1', 'student'),
(108, 'Shital1', 'student'),
(109, 'Pooja1', 'student'),
(110, 'Hetal1', 'student'),
(111, 'Raj1', 'student'),
(112, 'Suresh1', 'student'),
(113, 'Mahesh1', 'student'),
(114, 'Dinesh1', 'student'),
(115, 'Savita1', 'student'),
(116, 'Rani1', 'student'),
(117, 'Yash1', 'student'),
(118, 'Samadhan1', 'student'),
(119, 'Lalita1', 'student'),
(120, 'Snehal1', 'student'),
(121, 'Pramod1', 'student'),
(122, 'Snehal1', 'student'),
(123, 'Hetal1', 'student'),
(124, 'Piyush1', 'student'),
(125, 'Ramesh1', 'student'),
(126, 'Pooja1', 'student'),
(127, 'Suresh1', 'student'),
(128, 'Kiran1', 'student'),
(129, 'Ravi1', 'student'),
(130, 'Ram1', 'student'),
(131, 'Shital1', 'student'),
(132, 'Mangesh1', 'student'),
(133, 'Raj1', 'student'),
(134, 'Yash1', 'student'),
(135, 'Dinesh1', 'student'),
(136, 'Rani1', 'student'),
(137, 'Samadhan1', 'student'),
(138, 'Lalita1', 'student'),
(139, 'Mahesh1', 'student'),
(140, 'Savita1', 'student'),
(500, 'neha1', 'teacher');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `availablecourse`
--
ALTER TABLE `availablecourse`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `grade`
--
ALTER TABLE `grade`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `parents`
--
ALTER TABLE `parents`
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `report`
--
ALTER TABLE `report`
  ADD PRIMARY KEY (`reportid`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `takencoursebyteacher`
--
ALTER TABLE `takencoursebyteacher`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `teachers`
--
ALTER TABLE `teachers`
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD UNIQUE KEY `userid` (`userid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `availablecourse`
--
ALTER TABLE `availablecourse`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `grade`
--
ALTER TABLE `grade`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `report`
--
ALTER TABLE `report`
  MODIFY `reportid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=141;

--
-- AUTO_INCREMENT for table `takencoursebyteacher`
--
ALTER TABLE `takencoursebyteacher`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `teachers`
--
ALTER TABLE `teachers`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=501;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
